import { RawMain } from "@/components/legacy/raw-main";
import { settingsHtml } from "@/lib/legacy-html/settings";

export default function SettingsPage() {
  return (
    <main className="relative pt-16 bg-surface min-h-screen">
      <RawMain html={settingsHtml} />
    </main>
  );
}
