export type SyncStatus = "idle" | "running" | "success" | "error";

export interface Profile {
  id: string;
  full_name: string | null;
  tiktok_handle: string | null;
  avatar_url: string | null;
  last_synced_at: string | null;
  sync_status: SyncStatus;
  created_at: string;
  updated_at: string;
}

export interface TikTokVideo {
  id: string;
  user_id: string;
  tiktok_video_id: string | null;
  title: string;
  thumbnail_url: string | null;
  category: string;
  posted_at: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  avg_watch_time_seconds: number;
  completion_rate: number;
  retention_rate: number;
  engagement_rate: number;
  algorithm_diagnosis: string | null;
  created_at: string;
  updated_at: string;
}

export interface DailyTrend {
  id: string;
  user_id: string;
  trend_date: string;
  theme: string;
  hook_text: string;
  hook_score: number;
  retention_impact: number;
  source: "auto_engine" | "manual" | "ai_suggestion";
  is_active: boolean;
  created_at: string;
}

export interface GeneratedScript {
  id: string;
  user_id: string;
  theme: string;
  tone: string;
  based_on_daily_trends: boolean;
  hook: string;
  retention_beats: string[];
  cta: string;
  is_favorite: boolean;
  created_at: string;
}

