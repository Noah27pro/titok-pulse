"use client";

import { useEffect, useRef } from "react";

/**
 * Renderiza el markup <main> exportado desde el diseño de Stitch (TokPulse) tal cual,
 * y vuelve a ejecutar su <script> interno (si lo tiene) tras montar en el DOM,
 * ya que los scripts inyectados vía innerHTML no se ejecutan automáticamente.
 *
 * Esto preserva el diseño original al 100% sin tener que reescribir a mano
 * cientos de líneas de markup a JSX. Si en el futuro quieres convertir alguna
 * página a componentes React "nativos" (con estado real en vez de manipulación
 * directa del DOM), esta es la pieza a sustituir.
 */
export function RawMain({ html }: { html: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = ref.current;
    if (!container) return;

    // Vuelve a ejecutar cualquier <script> incluido en el HTML original
    const scripts = Array.from(container.querySelectorAll("script"));
    scripts.forEach((oldScript) => {
      const newScript = document.createElement("script");
      Array.from(oldScript.attributes).forEach((attr) =>
        newScript.setAttribute(attr.name, attr.value)
      );
      newScript.textContent = oldScript.textContent;
      oldScript.parentNode?.replaceChild(newScript, oldScript);
    });
  }, [html]);

  return <div ref={ref} dangerouslySetInnerHTML={{ __html: html }} />;
}
