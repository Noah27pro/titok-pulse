export function Topbar() {
  return (
    <header className="fixed top-0 left-[260px] right-0 h-16 bg-surface/80 backdrop-blur-xl z-40 shadow-[0_1px_8px_rgba(0,0,0,0.04)]">
      <div className="w-full h-full px-space-lg flex items-center justify-between gap-space-md">
        <div className="flex items-center gap-space-md flex-1 max-w-xl">
          <div className="relative w-full">
            <span className="material-symbols-outlined absolute left-space-sm top-1/2 -translate-y-1/2 text-on-surface-variant text-[18px]">
              search
            </span>
            <input
              className="w-full h-10 pl-9 pr-14 rounded-lg bg-surface-container-low font-body-sm text-body-sm text-on-surface placeholder:text-on-surface-variant focus:outline-none focus:bg-surface-container transition-all"
              placeholder="Buscar ganchos, vídeos, métricas o plantillas..."
              type="text"
            />
            <div className="absolute right-space-sm top-1/2 -translate-y-1/2 flex items-center gap-0.5 px-space-xs py-0.5 rounded bg-surface-container font-label-code text-label-code text-on-surface-variant">
              <span>⌘</span>
              <span>K</span>
            </div>
          </div>
          <div className="hidden xl:flex items-center gap-space-xs px-space-sm py-1.5 rounded-full bg-surface-container-low shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-secondary-container" />
            <span className="font-label-code text-label-code text-on-surface-variant">
              Algoritmo TikTok v24.2 • 04:00 AM
            </span>
          </div>
        </div>

        <div className="flex items-center gap-space-md shrink-0">
          <button
            className="flex items-center gap-space-xs px-space-md h-10 rounded-lg bg-primary-container text-on-primary-container font-headline-sm text-body-md font-semibold shadow-[0_0_20px_-4px_rgba(255,74,141,0.4)] hover:brightness-110 active:scale-95 transition-all"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">add</span>
            <span>Generar Guión IA</span>
          </button>
          <button
            aria-label="Notificaciones"
            className="relative p-space-sm rounded-lg text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[22px]">notifications</span>
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-primary-container" />
          </button>
          <div className="flex items-center gap-space-sm pl-space-sm">
            <div className="flex flex-col text-right hidden sm:flex">
              <span className="font-body-md text-body-md text-on-surface font-semibold leading-tight">
                Elena Vance
              </span>
              <span className="font-label-code text-label-code text-secondary font-medium leading-tight">
                Tier Enterprise
              </span>
            </div>
            <div className="relative">
              <img
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDquUCHd1ubgHqM4gIou8g-fZzfong49T3fDHMmIF8I8AuQYS3cUzErecVmymGh0tVPnlulVkz3h8IHKZx_hW174x6xpqn0_vrOvIPTlspoqKsG-5oATJOh-m1wNHXXLvEnsOMlPxcj306n30OjGT4vBhQhK4Uoddf5kcSDgLeigcHupKVZpPGy_9HQLgXzjEROMRgfoMKJ4QzW4UNky82ofitbpepjXQCm2Y1RYsWsDYi4hCcSbdw5EQ"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-secondary-fixed ring-2 ring-surface" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
