import { RawMain } from "@/components/legacy/raw-main";
import { videosHtml } from "@/lib/legacy-html/videos";

export default function VideosPage() {
  return (
    <main className="relative pt-16 bg-surface min-h-screen">
      <RawMain html={videosHtml} />
    </main>
  );
}
