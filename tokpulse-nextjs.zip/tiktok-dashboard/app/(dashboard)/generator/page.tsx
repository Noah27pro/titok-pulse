import { RawMain } from "@/components/legacy/raw-main";
import { strategyHtml } from "@/lib/legacy-html/strategy";

export default function GeneratorPage() {
  return (
    <main className="relative pt-16 bg-surface min-h-screen">
      <RawMain html={strategyHtml} />
    </main>
  );
}
