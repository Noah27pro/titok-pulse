import { RawMain } from "@/components/legacy/raw-main";
import { dashboardHtml } from "@/lib/legacy-html/dashboard";

export default function DashboardPage() {
  return (
    <main className="relative pt-16 bg-surface min-h-screen">
      <RawMain html={dashboardHtml} />
    </main>
  );
}
