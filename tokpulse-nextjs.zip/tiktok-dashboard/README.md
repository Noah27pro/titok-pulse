# TokPulse — Creative Intelligence

Dashboard de analítica y estrategia de contenido para creadores de TikTok. Next.js 14 (App Router) + TypeScript + Tailwind CSS, con el diseño **TokPulse** (exportado originalmente de Stitch) integrado y compilado correctamente vía PostCSS — sin el aviso de `cdn.tailwindcss.com`.

## Empezar

```bash
npm install
npm run dev
```

Abre `http://localhost:3000` — redirige a `/dashboard`.

## Subir a GitHub

```bash
git init
git add .
git commit -m "TokPulse dashboard"
git branch -M main
git remote add origin https://github.com/tu-usuario/tu-repo.git
git push -u origin main
```

El `.gitignore` ya excluye `node_modules/`, `.next/` y cualquier `.env*local`, así que GitHub reconoce el repo como proyecto Next.js sin arrastrar dependencias ni secretos.

## Conectar Supabase (más adelante)

1. Copia `.env.example` a `.env.local`.
2. Rellena `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` y `SUPABASE_SERVICE_ROLE_KEY` con tus valores reales de Supabase → Project Settings → API.
3. `.env.local` nunca se sube al repo (está en `.gitignore`), así que tus claves se quedan solo en tu máquina.

## Estructura

```
app/
├── layout.tsx                 # Fuentes (Geist, JetBrains Mono, Material Symbols)
├── globals.css                # Reset + utilidad .material-symbols-outlined
└── (dashboard)/
    ├── layout.tsx              # Sidebar + Topbar fijos
    ├── dashboard/page.tsx
    ├── videos/page.tsx
    ├── themes/page.tsx
    ├── generator/page.tsx      # (ruta "strategy" en el diseño original)
    └── settings/page.tsx

components/
├── layout/        sidebar.tsx, topbar.tsx     — componentes React reales
└── legacy/        raw-main.tsx                — inyecta el HTML de cada página
                                                   y reejecuta su <script> interno

lib/
├── legacy-html/   dashboard.ts, videos.ts...  — el markup de cada página,
│                                                 extraído del export de Stitch
├── types.ts       tipos de datos (Video, Trend, Script…)
└── utils.ts       cn(), helpers de formato

tailwind.config.ts  — paleta y tipografía exactas del design system TokPulse
```

## Nota sobre `components/legacy/raw-main.tsx`

Cada página usa el HTML **original** del export de Stitch (`lib/legacy-html/*.ts`), inyectado tal cual para no perder ningún detalle visual. Es la vía rápida para tener el diseño ya compilado con Tailwind real (no CDN). Si más adelante quieres reescribir alguna página como componentes React "nativos" (con estado, props, data real de Supabase en vez de HTML estático), esa página es la que hay que migrar — el Sidebar y el Topbar ya están hechos así, como referencia del patrón a seguir.
