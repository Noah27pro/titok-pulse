import { RawMain } from "@/components/legacy/raw-main";
import { themesHtml } from "@/lib/legacy-html/themes";

export default function ThemesPage() {
  return (
    <main className="relative pt-16 bg-surface min-h-screen">
      <RawMain html={themesHtml} />
    </main>
  );
}
