"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { path: "dashboard", href: "/dashboard", label: "Dashboard", icon: "grid_view", badge: null as string | null },
  { path: "videos", href: "/videos", label: "Analítica de Vídeos", icon: "play_circle", badge: null },
  { path: "themes", href: "/themes", label: "Radar de Temáticas", icon: "radar", badge: "LIVE" },
  { path: "strategy", href: "/generator", label: "Generador Guiones", icon: "auto_awesome", badge: "AI PRO" },
  { path: "settings", href: "/settings", label: "Configuración & API", icon: "tune", badge: null },
];

const ACTIVE_CLASSES =
  "bg-primary-container text-on-primary-container font-semibold shadow-[0_0_20px_-4px_rgba(255,74,141,0.35)]";

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed left-0 top-0 h-full w-[260px] bg-surface-container-lowest z-50 flex flex-col justify-between shadow-[0_1px_8px_rgba(0,0,0,0.04)]">
      <div className="flex flex-col">
        <div className="h-16 px-space-md flex items-center justify-between">
          <div className="flex items-center gap-space-sm">
            <img
              alt="TokPulse Brand Logo"
              className="h-8 w-auto object-contain"
              src="https://lh3.googleusercontent.com/aida/AEtjO1VjKLlAPYSTLGQDU12QtQ1DJkF9tXy4FlMof5CyZVvZMRbnr5WN1tErKV9iqA-psCO60Dkd7_QoWZsO4BnW7lH8GQEsGlC3h7S6YGMDkXZZSemeRMl9j2bHFPpLK5PMQ-mVSVHgbTDg2vSMz1FITYWNb9mjM46qewY5bCL2R_XuPRthNzo1icFu7gjWZLFDxF5iwYhjirTL833UqcsbacMSKadSc4YsPloKXKXb4H5STxuaHXCpmgRZzAgE"
            />
            <div className="flex flex-col">
              <span className="font-headline-sm text-headline-sm text-on-surface font-bold tracking-tight">
                TokPulse
              </span>
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                Intelligence
              </span>
            </div>
          </div>
          <button
            aria-label="Colapsar menú lateral"
            className="p-space-xs rounded text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">dock_to_right</span>
          </button>
        </div>

        <div className="px-space-md py-space-sm">
          <div className="bg-surface-container-low rounded-lg p-space-sm flex items-center justify-between group cursor-pointer hover:bg-surface-container transition-colors">
            <div className="flex items-center gap-space-sm overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-surface-container-high flex items-center justify-center shrink-0 text-primary-fixed">
                <span className="material-symbols-outlined text-[18px]">music_note</span>
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-space-xs">
                  <span className="font-body-sm text-body-sm text-on-surface font-semibold truncate">
                    @creatorpulse
                  </span>
                  <span className="material-symbols-outlined text-secondary text-[14px]">verified</span>
                </div>
                <span className="font-label-code text-label-code text-on-surface-variant">
                  1.4M followers
                </span>
              </div>
            </div>
            <span className="material-symbols-outlined text-on-surface-variant text-[18px]">unfold_more</span>
          </div>
        </div>

        <nav className="px-space-sm mt-space-sm flex flex-col gap-space-xs">
          {NAV_ITEMS.map((item) => {
            const active = pathname?.startsWith(item.href);
            return (
              <Link
                key={item.path}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex items-center justify-between px-space-md py-space-sm rounded-lg transition-all",
                  active
                    ? ACTIVE_CLASSES
                    : "text-on-surface-variant hover:bg-surface-container hover:text-on-surface"
                )}
              >
                <div className="flex items-center gap-space-sm">
                  <span className="material-symbols-outlined text-[20px]">{item.icon}</span>
                  <span className="font-body-md text-body-md">{item.label}</span>
                </div>
                {active && <span className="w-1.5 h-1.5 rounded-full bg-primary-container opacity-80" />}
                {!active && item.badge === "LIVE" && (
                  <span className="font-label-code text-label-code px-space-xs py-0.5 rounded bg-surface-container-high text-secondary">
                    LIVE
                  </span>
                )}
                {!active && item.badge === "AI PRO" && (
                  <span className="font-label-code text-label-code px-space-xs py-0.5 rounded bg-secondary-container text-on-secondary-container font-semibold">
                    AI PRO
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-space-md flex flex-col gap-space-sm bg-surface-container-lowest">
        <div className="p-space-sm rounded-lg bg-surface-container-low flex flex-col gap-space-xs">
          <div className="flex items-center gap-space-sm">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary-fixed opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-secondary-fixed-dim" />
            </span>
            <span className="font-label-code text-label-code text-on-surface font-medium">
              TikTok & Supabase Live
            </span>
          </div>
          <span className="font-label-code text-label-code text-on-surface-variant">
            Sincronizado hace 4 min
          </span>
        </div>
        <a
          className="flex items-center justify-between px-space-sm py-space-xs rounded text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
          href="#"
        >
          <div className="flex items-center gap-space-sm">
            <span className="material-symbols-outlined text-[18px]">help_outline</span>
            <span className="font-body-sm text-body-sm">Documentación & Soporte</span>
          </div>
          <span className="material-symbols-outlined text-[14px]">open_in_new</span>
        </a>
      </div>
    </aside>
  );
}
