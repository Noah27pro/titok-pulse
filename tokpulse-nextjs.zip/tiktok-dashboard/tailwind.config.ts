import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      "colors": {
            "on-primary-container": "#590028",
            "inverse-on-surface": "#2f3036",
            "surface-variant": "#34343a",
            "primary-container": "#ff4a8d",
            "tertiary-container": "#8e909c",
            "primary": "#ffb1c4",
            "surface-container-highest": "#34343a",
            "on-tertiary-fixed": "#181b25",
            "secondary-container": "#00eefc",
            "on-tertiary-fixed-variant": "#444651",
            "on-surface-variant": "#e5bcc5",
            "surface-dim": "#121318",
            "surface-tint": "#ffb1c4",
            "secondary-fixed-dim": "#00dbe9",
            "on-primary-fixed-variant": "#8f0044",
            "secondary": "#d3fbff",
            "primary-fixed-dim": "#ffb1c4",
            "outline-variant": "#5c3f46",
            "on-secondary-container": "#00686f",
            "on-tertiary-container": "#272933",
            "on-secondary-fixed": "#002022",
            "surface-container-lowest": "#0d0e13",
            "tertiary": "#c4c6d2",
            "secondary-fixed": "#7df4ff",
            "tertiary-fixed": "#e0e2ef",
            "on-surface": "#e3e1e9",
            "on-secondary-fixed-variant": "#004f54",
            "error": "#ffb4ab",
            "tertiary-fixed-dim": "#c4c6d2",
            "on-background": "#e3e1e9",
            "inverse-primary": "#ba005b",
            "background": "#121318",
            "outline": "#ac878f",
            "on-secondary": "#00363a",
            "surface": "#121318",
            "on-error-container": "#ffdad6",
            "error-container": "#93000a",
            "surface-container-low": "#1a1b21",
            "on-primary": "#65002e",
            "on-tertiary": "#2d303a",
            "primary-fixed": "#ffd9e1",
            "on-primary-fixed": "#3f001a",
            "inverse-surface": "#e3e1e9",
            "surface-bright": "#38393f",
            "surface-container": "#1e1f25",
            "surface-container-high": "#292a2f",
            "on-error": "#690005"
      },
      "borderRadius": {
            "DEFAULT": "0.25rem",
            "lg": "0.5rem",
            "xl": "0.75rem",
            "full": "9999px"
      },
      "spacing": {
            "margin-mobile": "1rem",
            "space-lg": "1.5rem",
            "margin": "2rem",
            "space-sm": "0.5rem",
            "gutter": "1.25rem",
            "gutter-mobile": "0.75rem",
            "space-xs": "0.25rem",
            "space-md": "1rem",
            "space-xl": "2.5rem"
      },
      "fontFamily": {
            "body-lg": [
                  "Geist"
            ],
            "headline-md": [
                  "Geist"
            ],
            "body-sm": [
                  "Geist"
            ],
            "label-code": [
                  "JetBrains Mono"
            ],
            "display-mobile": [
                  "Geist"
            ],
            "body-md": [
                  "Geist"
            ],
            "metric-md": [
                  "JetBrains Mono"
            ],
            "metric-xl": [
                  "JetBrains Mono"
            ],
            "headline-lg-mobile": [
                  "Geist"
            ],
            "headline-lg": [
                  "Geist"
            ],
            "display": [
                  "Geist"
            ],
            "headline-sm": [
                  "Geist"
            ],
            "label-caps": [
                  "Geist"
            ]
      },
      "fontSize": {
            "body-lg": [
                  "1rem",
                  {
                        "lineHeight": "1.6",
                        "letterSpacing": "-0.01em",
                        "fontWeight": "400"
                  }
            ],
            "headline-md": [
                  "1.5rem",
                  {
                        "lineHeight": "1.3",
                        "letterSpacing": "-0.02em",
                        "fontWeight": "600"
                  }
            ],
            "body-sm": [
                  "0.75rem",
                  {
                        "lineHeight": "1.4",
                        "letterSpacing": "0.01em",
                        "fontWeight": "400"
                  }
            ],
            "label-code": [
                  "0.75rem",
                  {
                        "lineHeight": "1.2",
                        "letterSpacing": "0.04em",
                        "fontWeight": "500"
                  }
            ],
            "display-mobile": [
                  "2.25rem",
                  {
                        "lineHeight": "1.15",
                        "letterSpacing": "-0.03em",
                        "fontWeight": "700"
                  }
            ],
            "body-md": [
                  "0.875rem",
                  {
                        "lineHeight": "1.5",
                        "letterSpacing": "0em",
                        "fontWeight": "400"
                  }
            ],
            "metric-md": [
                  "1.25rem",
                  {
                        "lineHeight": "1.2",
                        "letterSpacing": "-0.01em",
                        "fontWeight": "500"
                  }
            ],
            "metric-xl": [
                  "2rem",
                  {
                        "lineHeight": "1.1",
                        "letterSpacing": "-0.02em",
                        "fontWeight": "600"
                  }
            ],
            "headline-lg-mobile": [
                  "1.75rem",
                  {
                        "lineHeight": "1.25",
                        "letterSpacing": "-0.02em",
                        "fontWeight": "600"
                  }
            ],
            "headline-lg": [
                  "2.25rem",
                  {
                        "lineHeight": "1.2",
                        "letterSpacing": "-0.03em",
                        "fontWeight": "600"
                  }
            ],
            "display": [
                  "3.5rem",
                  {
                        "lineHeight": "1.1",
                        "letterSpacing": "-0.04em",
                        "fontWeight": "700"
                  }
            ],
            "headline-sm": [
                  "1.125rem",
                  {
                        "lineHeight": "1.4",
                        "letterSpacing": "-0.01em",
                        "fontWeight": "600"
                  }
            ],
            "label-caps": [
                  "0.6875rem",
                  {
                        "lineHeight": "1.2",
                        "letterSpacing": "0.08em",
                        "fontWeight": "600"
                  }
            ]
      }
},
  },
  plugins: [],
};

export default config;
